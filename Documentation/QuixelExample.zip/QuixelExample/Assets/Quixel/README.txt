Documentation can be found here:
https://docs.google.com/document/d/1ha5eLEsvmYe76cXGLJBBtMrsIqIsPUjYbMszIoxdXnI/edit?usp=sharing

Hello and welcome to the now open source Quixel terrain engine!

This is a project that initially started as a hobby project, to see if
I could create an efficient voxel engine for Unity. Initially, I planned
on selling this on the Unity asset store, however life happened suddenly
and I'm unable to work on this as much as before, if at all. So here it
is, open sourced under the GPLv2 license. You're free to use it for
commercial use, however I'd really love to hear about any project using
this. Thanks!

Suppose I'll keep the important updates here.

4/14/2014:
Uploaded project to GitHub.

Known Bugs:
Editing terrain with NodeEditor does not work if the initial voxel width is not 1.